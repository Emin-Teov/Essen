ENHANCED GAME EFFECTS PACK
==========================

Contents
--------
24 enhanced Wavefront OBJ assets and the shared effects.mtl material library.

What was improved
-----------------
- Added material-aware vertex normals to improve shading and make curved forms read
  more clearly under real-time lighting.
- Improved specular response for steel, gold/gems, wood, paper and organic materials.
- Preserved existing mesh positions, object names, material names, filenames,
  transparency, emissive values and custom 'essen_flags' metadata.
- Preserved the original relative asset layout.

Integration
-----------
1. Keep effects.mtl beside the OBJ files.
2. Import the OBJ assets using your engine's normal OBJ importer.
3. Enable normal import and material import where supported.
4. The custom 'essen_flags' comments are engine-specific metadata; keep the original
   parser/loader if your project reads these flags.
5. If your engine ignores MTL specular/emissive fields, configure those channels in
   the engine's material editor/shader.

Compatibility note
------------------
OBJ/MTL does not contain animation, particle simulation, volumetric smoke, or shader
graphs. These assets remain static meshes; animated appearance is normally driven by
your game's particle system or shader.
