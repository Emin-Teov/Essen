REDESIGNED GAME VFX OBJ PACK

23 redesigned assets with substantially rebuilt composite geometry. Includes generated vertex normals and a shared MTL material library.

Import notes: OBJ is static mesh geometry; animated fire/smoke/energy motion, particles, transparency, emissive bloom and shader effects must be implemented in your game engine. Check scale/orientation in-engine before replacing production assets. Original filenames retained.
